class TestPytestWorks:
    def test_pytest(self):
        assert 1 == 1
