import { initialize } from "./random_number";

initialize();
